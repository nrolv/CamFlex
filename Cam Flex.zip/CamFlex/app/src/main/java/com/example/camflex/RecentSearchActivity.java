package com.example.camflex;

import android.app.Activity;

public class RecentSearchActivity extends Activity {
}
