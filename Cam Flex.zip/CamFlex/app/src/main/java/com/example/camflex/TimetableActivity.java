package com.example.camflex;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class TimetableActivity extends AppCompatActivity {

    private GridLayout gridTimetable;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timetable);

        gridTimetable = findViewById(R.id.grid_timetable);

        // 수업 데이터 예시
        // (요일: 월=1, 화=2, 수=3, 목=4, 금=5)
        // 시작 시간: 9시 기준 인덱스 (9시=0, 10시=1, ... )
        // 시간 길이: 1(1시간), 2(2시간) 등
        // 색상은 임의 지정

        addClassBlock("SW융합프로젝트", "6302", 2, 1, 2, Color.parseColor("#F8C8C8"));  // 화요일 10시~11시
        addClassBlock("SW융합캡스톤디자인(2)", "6601", 3, 1, 2, Color.parseColor("#C8E6C9"));  // 수요일 10시~11시
        addClassBlock("소프트웨어테스팅", "6601", 1, 4, 1, Color.parseColor("#E0C8C8"));  // 월요일 2시~3시
        addClassBlock("소프트웨어보안", "6104", 2, 4, 1, Color.parseColor("#F0F8C0"));  // 화요일 2시~3시
        addClassBlock("인공지능", "", 3, 4, 1, Color.parseColor("#B0C4DE"));  // 수요일 2시~3시
    }

    /**
     * 수업 블록 추가 함수
     *
     * @param title           수업명
     * @param room            강의실
     * @param dayOfWeek       요일 (월=1, 화=2, ...)
     * @param startTime       시작 시간(9시 기준 인덱스, 9시는 0)
     * @param duration        시간 길이(몇 시간 수업인지)
     * @param backgroundColor 배경색
     */
    private void addClassBlock(String title, String room, int dayOfWeek, int startTime, int duration, int backgroundColor) {
        LayoutInflater inflater = LayoutInflater.from(this);
        LinearLayout classBlock = (LinearLayout) inflater.inflate(R.layout.item_class_block, gridTimetable, false);

        TextView tvTitle = classBlock.findViewById(R.id.text_class_title);
        TextView tvRoom = classBlock.findViewById(R.id.text_class_room);

        tvTitle.setText(title);
        tvRoom.setText(room);
        classBlock.setBackgroundColor(backgroundColor);

        // GridLayout 배치 설정
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();

        // ### 수정된 부분 ###
        // rowSpec: 시작 위치, 차지하는 칸 수, 가중치 순으로 설정
        params.rowSpec = GridLayout.spec(startTime, duration, (float) duration);
        // columnSpec: 시작 위치, 차지하는 칸 수, 가중치 순으로 설정
        params.columnSpec = GridLayout.spec(dayOfWeek, 1, 1f); // 1칸을 차지하며 가중치 1f를 가짐

        // 가중치를 사용하기 위해 너비와 높이를 0으로 설정
        params.width = 0;
        params.height = 0;
        params.setMargins(4, 4, 4, 4);

        classBlock.setLayoutParams(params);
        gridTimetable.addView(classBlock);
    }
}