package com.example.camflex;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class CategoryFragment extends Fragment {

    private LinearLayout layoutJjim, layoutMyPosts, layoutHotBoard,
            layoutSchoolNews, layoutLostFound, layoutClothing, layoutTextbook;
    private TextView tvTip;

    public CategoryFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // fragment.xml 사용
        return inflater.inflate(R.layout.fragment_category, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 연결
        tvTip          = view.findViewById(R.id.tv_tip_message);
        layoutJjim     = view.findViewById(R.id.layout_jjim);
        layoutMyPosts  = view.findViewById(R.id.layout_my_posts);
        layoutHotBoard = view.findViewById(R.id.layout_hot_board);
        layoutSchoolNews = view.findViewById(R.id.layout_school_news);
        layoutLostFound  = view.findViewById(R.id.layout_lost_found);
        layoutClothing   = view.findViewById(R.id.layout_clothing);
        layoutTextbook   = view.findViewById(R.id.layout_textbook);

        // 클릭 리스너 설정
        setClick(layoutJjim, "찜 목록");
        setClick(layoutMyPosts, "내가 쓴 글");
        setClick(layoutHotBoard, "Hot 게시판");
        setClick(layoutSchoolNews, "학교소식");
        setClick(layoutLostFound, "분실물");
        setClick(layoutClothing, "의류");
        setClick(layoutTextbook, "교재");

        // Tip 클릭 예시
        if (tvTip != null) {
            tvTip.setOnClickListener(v ->
                    Toast.makeText(requireContext(), "거래는 밝은 인사부터 😊", Toast.LENGTH_SHORT).show()
            );
        }
    }

    private void setClick(LinearLayout layout, String title) {
        if (layout == null) return;
        layout.setOnClickListener(v -> {
            // TODO: 다른 화면으로 이동할 때 Intent 사용
            Toast.makeText(requireContext(), "'" + title + "' 클릭됨", Toast.LENGTH_SHORT).show();
        });
    }
}