package com.example.camflex;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ImageButton navHome, navCategory, navChat, navProfile;
    private ImageButton btnSearch, btnNotification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // 시스템 바 여백 적용
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 상단 버튼
        btnSearch = findViewById(R.id.btnSearch);
        btnNotification = findViewById(R.id.btnNotification);

        // 하단 네비 버튼
        navHome = findViewById(R.id.nav_home);
        navCategory = findViewById(R.id.nav_board);
        navChat = findViewById(R.id.nav_chat);
        navProfile = findViewById(R.id.nav_profile);

        // 초기 화면: 홈
        loadFragment(new HomeFragment());

        // 🔍 검색 버튼 클릭
        btnSearch.setOnClickListener(v ->
                Toast.makeText(MainActivity.this, "검색 버튼 클릭됨", Toast.LENGTH_SHORT).show()
        );

        // 🔔 알림 버튼 클릭
        btnNotification.setOnClickListener(v ->
                Toast.makeText(MainActivity.this, "알림 버튼 클릭됨", Toast.LENGTH_SHORT).show()
        );

        // 🏠 홈 버튼
        navHome.setOnClickListener(v -> loadFragment(new HomeFragment()));

        // 📋 게시판 버튼
        navCategory.setOnClickListener(v -> loadFragment(new CategoryFragment()));

        // 💬 채팅 버튼
        navChat.setOnClickListener(v -> loadFragment(new ChatFragment()));

        // 👤 프로필 버튼
        navProfile.setOnClickListener(v -> loadFragment(new ProfileFragment()));
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}