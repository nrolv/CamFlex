package com.example.camflex;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class EditProfile2Activity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit2);

        ImageView btnClose = findViewById(R.id.btnClose);
        TextView btnDone = findViewById(R.id.btnDone);

        btnClose.setOnClickListener(v -> finish());
        btnDone.setOnClickListener(v -> finish());
    }
}
