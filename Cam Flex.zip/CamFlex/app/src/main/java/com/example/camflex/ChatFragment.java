package com.example.camflex;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ChatFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_chat, container, false);

        View chatItem1 = rootView.findViewById(R.id.chat_item_1);
        if (chatItem1 != null) {
            chatItem1.setOnClickListener(v -> {
                Intent intent = new Intent(getActivity(), Chat2Activity.class);
                startActivity(intent);
            });
        }

        return rootView;
    }
}
