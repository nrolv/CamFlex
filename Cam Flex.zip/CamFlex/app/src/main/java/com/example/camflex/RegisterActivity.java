package com.example.camflex;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member); // 👉 네가 올려준 xml 파일명으로 바꿔줘

        Button btnNext = findViewById(R.id.buttonRegister);

        btnNext.setOnClickListener(v -> {
            // SignUpActivity 화면으로 이동
            Intent intent = new Intent(RegisterActivity.this, SignUpActivity.class);
            startActivity(intent);
        });
    }
}
