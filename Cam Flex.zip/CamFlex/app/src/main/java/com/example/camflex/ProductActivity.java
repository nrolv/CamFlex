package com.example.camflex;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProductActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        // Intent로 전달받은 데이터 꺼내기
        String title = getIntent().getStringExtra("title");
        String price = getIntent().getStringExtra("price");
        int imageResId = getIntent().getIntExtra("imageResId", R.drawable.a11); // 기본 이미지

        // XML의 View들과 연결
        TextView titleView = findViewById(R.id.titleTextView);
        TextView priceView = findViewById(R.id.priceTextView);
        ImageView imageView = findViewById(R.id.mainImageView);

        // 데이터 세팅
        if (titleView != null) titleView.setText(title);
        if (priceView != null) priceView.setText(price);
        if (imageView != null) imageView.setImageResource(imageResId);
    }
}
