package com.example.camflex;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

// 게시물 데이터 클래스
class Post {
    String title;
    String price;
    String date;
    int imageResId;

    Post(String title, String price, String date, int imageResId) {
        this.title = title;
        this.price = price;
        this.date = date;
        this.imageResId = imageResId;
    }
}

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private PostAdapter adapter;
    private ArrayList<Post> postList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = rootView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // 예시 데이터 추가
        postList.add(new Post("후지필름", "278,000원", "07/28", R.drawable.a11));
        postList.add(new Post("캐논 카메라", "350,000원", "07/25", R.drawable.a11));
        postList.add(new Post("니콘 렌즈", "180,000원", "07/20", R.drawable.a11));

        adapter = new PostAdapter(postList);
        recyclerView.setAdapter(adapter);

        return rootView;
    }
}
