package com.example.camflex;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Chat2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat2);  // xml 레이아웃 연결

        ImageButton menuIcon = findViewById(R.id.menu_icon);
        menuIcon.setOnClickListener(v -> {
            Intent intent = new Intent(Chat2Activity.this, Chat3Activity.class);
            startActivity(intent);
        });

        Button btnFlex = findViewById(R.id.btn_flex);
        btnFlex.setOnClickListener(v -> {
            Intent intent = new Intent(Chat2Activity.this, ScheduleActivity.class);
            startActivity(intent);
        });

        ImageView gradeIcon = findViewById(R.id.grade_icon);
        gradeIcon.setOnClickListener(v -> {
            Intent intent = new Intent(Chat2Activity.this, HeartActivity.class);
            startActivity(intent);
        });

    }
}
