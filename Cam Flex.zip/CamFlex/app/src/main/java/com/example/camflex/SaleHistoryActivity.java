package com.example.camflex;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class SaleHistoryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell_his);
    }
}