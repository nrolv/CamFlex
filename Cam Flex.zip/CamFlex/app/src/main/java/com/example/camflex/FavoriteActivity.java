package com.example.camflex;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class FavoriteActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 찜목록 화면 레이아웃 지정
        setContentView(R.layout.activity_att);
    }
}
