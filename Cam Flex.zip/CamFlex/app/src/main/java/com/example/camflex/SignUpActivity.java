package com.example.camflex;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup); // 👉 sign_up.xml 파일명 맞게 수정

        Button btnNext = findViewById(R.id.button_next);
        ImageButton btnClose = findViewById(R.id.button_close);

        // "완료" 버튼 → 로그인 화면 이동
        btnNext.setOnClickListener(v -> {
            Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });

        // "닫기" 버튼 → 회원가입(RegisterActivity) 화면으로 이동
        btnClose.setOnClickListener(v -> {
            Intent intent = new Intent(SignUpActivity.this, RegisterActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
