package com.example.camflex;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup); // 너가 준 ConstraintLayout XML 파일 이름이라고 가정

        Button buttonNext = findViewById(R.id.button_next);
        buttonNext.setOnClickListener(v -> {
            // 완료 버튼 클릭 시 MainActivity로 이동
            Intent intent = new Intent(SignUpActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish(); // 이 액티비티 종료
        });

        // 닫기 버튼 등 필요한 거 있으면 여기서 리스너 추가 가능
    }
}
